# Laporan Audit & Validasi Paket `Latsol Konstruksi 01` (50 Soal CBT)

## 1. Ringkasan Paket & Validasi 50 Soal
- **Nama Paket**: `Latsol Konstruksi 01` (`setId`: `latsol-konstruksi-01`)
- **Bidang Materi**: Konstruksi / Teknik Sipil (`試験区分(土木) 実技試験テキスト 第5章`, Halaman PDF 5–47 / Halaman Teks 100–142)
- **Jumlah Soal**: **50 soal unik** (`konstruksi01-q001` s/d `konstruksi01-q050`), masing-masing memiliki **4 opsi (`A`, `B`, `C`, `D`)** dan **1 jawaban benar**.
- **Distribusi Kunci Jawaban**: **A = 14**, **B = 13**, **C = 12**, **D = 11** (Total = 50).
- **Cakupan Visual**: **44 dari 50 soal (88%) merupakan soal bergambar**, terdiri atas **28 soal dengan gambar pertanyaan (`questionImage`)** dan **16 soal dengan 4 gambar opsi terpisah (`option-a` s/d `option-d`, 64 gambar)** = **total 67 file PNG unik** di `assets/questions/` (0 screenshot halaman penuh, 0 duplikasi gambar).
- **Cakupan Kotoba**: **1891 entri kosakata leksikal utuh** (mencakup seluruh istilah pada pertanyaan dan keempat opsi A, B, C, D, dengan 0 pemecahan Kanji tunggal).

## 2. Tabel Pemetaan 50 Soal ke Halaman PDF & Aset Visual
| No | ID Soal | Hlm. PDF (Teks) | Subbab Materi | Kunci | Mode Visual | Jumlah Kotoba |
|---:|---|---:|---|---|---|---:|
| 1 | `konstruksi01-q001` | Hlm. 5 (100) | `5.1.1 建設機械` | **A** | Gambar Soal | 43 kata |
| 2 | `konstruksi01-q002` | Hlm. 5 (100) | `5.1.1 建設機械` | **B** | Gambar Soal | 41 kata |
| 3 | `konstruksi01-q003` | Hlm. 6 (101) | `5.1.1 建設機械` | **D** | 4 Gambar Opsi (A–D) | 24 kata |
| 4 | `konstruksi01-q004` | Hlm. 6 (101) | `5.1.1 建設機械` | **B** | Gambar Soal | 26 kata |
| 5 | `konstruksi01-q005` | Hlm. 6 (101) | `5.1.1 建設機械` | **C** | Gambar Soal | 37 kata |
| 6 | `konstruksi01-q006` | Hlm. 7 (102) | `5.1.1 建設機械` | **D** | 4 Gambar Opsi (A–D) | 25 kata |
| 7 | `konstruksi01-q007` | Hlm. 8 (103) | `5.1.2 推進トンネル工事` | **C** | Gambar Soal | 35 kata |
| 8 | `konstruksi01-q008` | Hlm. 8 (103) | `5.1.2 推進トンネル工事` | **A** | Teks Murni | 31 kata |
| 9 | `konstruksi01-q009` | Hlm. 9 (104) | `5.1.3 海洋土木工事` | **B** | Gambar Soal | 36 kata |
| 10 | `konstruksi01-q010` | Hlm. 9 (104) | `5.1.3 海洋土木工事` | **A** | Gambar Soal | 42 kata |
| 11 | `konstruksi01-q011` | Hlm. 10 (105) | `5.1.3 海洋土木工事` | **A** | 4 Gambar Opsi (A–D) | 30 kata |
| 12 | `konstruksi01-q012` | Hlm. 10 (105) | `5.1.3 海洋土木工事` | **B** | Teks Murni | 29 kata |
| 13 | `konstruksi01-q013` | Hlm. 11 (106) | `5.1.4 さく井工事` | **C** | Teks Murni | 25 kata |
| 14 | `konstruksi01-q014` | Hlm. 12 (107) | `5.1.5 ウェルポイント工事` | **D** | Teks Murni | 34 kata |
| 15 | `konstruksi01-q015` | Hlm. 12 (107) | `5.1.6 舗装工事` | **B** | Teks Murni | 37 kata |
| 16 | `konstruksi01-q016` | Hlm. 13 (108) | `5.1.6 舗装工事` | **C** | Gambar Soal | 35 kata |
| 17 | `konstruksi01-q017` | Hlm. 13 (108) | `5.1.7 杭工事` | **A** | Teks Murni | 37 kata |
| 18 | `konstruksi01-q018` | Hlm. 14 (109) | `5.1.8 とび工事` | **D** | Gambar Soal | 44 kata |
| 19 | `konstruksi01-q019` | Hlm. 15 (110) | `5.1.8 とび工事` | **A** | Gambar Soal | 40 kata |
| 20 | `konstruksi01-q020` | Hlm. 15 (110) | `5.1.8 とび工事` | **B** | 4 Gambar Opsi (A–D) | 28 kata |
| 21 | `konstruksi01-q021` | Hlm. 16 (111) | `5.1.8 とび工事` | **D** | 4 Gambar Opsi (A–D) | 36 kata |
| 22 | `konstruksi01-q022` | Hlm. 17 (112) | `5.1.8 とび工事 / 5.1.9 鉄骨工事` | **A** | Gambar Soal | 39 kata |
| 23 | `konstruksi01-q023` | Hlm. 17 (112) | `5.1.9 鉄骨工事` | **B** | Gambar Soal | 32 kata |
| 24 | `konstruksi01-q024` | Hlm. 18 (113) | `5.1.10 鉄筋工事` | **D** | 4 Gambar Opsi (A–D) | 25 kata |
| 25 | `konstruksi01-q025` | Hlm. 18 (113) | `5.1.10 鉄筋工事` | **C** | Gambar Soal | 38 kata |
| 26 | `konstruksi01-q026` | Hlm. 19 (114) | `5.1.10 鉄筋工事` | **B** | 4 Gambar Opsi (A–D) | 37 kata |
| 27 | `konstruksi01-q027` | Hlm. 20 (115) | `5.1.11 鉄筋継手工事` | **A** | Gambar Soal | 46 kata |
| 28 | `konstruksi01-q028` | Hlm. 21 (116) | `5.1.11 鉄筋継手工事` | **C** | Gambar Soal | 40 kata |
| 29 | `konstruksi01-q029` | Hlm. 21 (116) | `5.1.12 溶接工事` | **D** | Gambar Soal | 42 kata |
| 30 | `konstruksi01-q030` | Hlm. 22 (117) | `5.1.12 溶接工事` | **A** | Gambar Soal | 43 kata |
| 31 | `konstruksi01-q031` | Hlm. 22 (117) | `5.1.13 型枠工事` | **C** | Gambar Soal | 44 kata |
| 32 | `konstruksi01-q032` | Hlm. 23 (118) | `5.1.13 型枠工事` | **B** | Gambar Soal | 38 kata |
| 33 | `konstruksi01-q033` | Hlm. 24 (119) | `5.1.13 型枠工事` | **B** | 4 Gambar Opsi (A–D) | 25 kata |
| 34 | `konstruksi01-q034` | Hlm. 25 (120) | `5.1.14 コンクリート圧送工事` | **D** | Teks Murni | 46 kata |
| 35 | `konstruksi01-q035` | Hlm. 26 (121) | `5.1.14 コンクリート圧送工事 / 5.2.4 測る` | **A** | Gambar Soal | 44 kata |
| 36 | `konstruksi01-q036` | Hlm. 27 (122) | `5.2.15 塗装工事` | **C** | Gambar Soal | 22 kata |
| 37 | `konstruksi01-q037` | Hlm. 28 (123) | `5.2.15 塗装工事` | **A** | Gambar Soal | 42 kata |
| 38 | `konstruksi01-q038` | Hlm. 29 (124) | `5.2.16 造園工事` | **B** | Gambar Soal | 40 kata |
| 39 | `konstruksi01-q039` | Hlm. 30 (125) | `5.2.16 造園工事` | **D** | Gambar Soal | 39 kata |
| 40 | `konstruksi01-q040` | Hlm. 31 (126) | `5.2.1 電動工具` | **A** | Gambar Soal | 40 kata |
| 41 | `konstruksi01-q041` | Hlm. 32 (127) | `5.2.1 電動工具` | **C** | Gambar Soal | 41 kata |
| 42 | `konstruksi01-q042` | Hlm. 34 (129) | `5.2.2 掘る・均す・締め固める` | **B** | Gambar Soal | 55 kata |
| 43 | `konstruksi01-q043` | Hlm. 35 (130) | `5.2.3 墨出し・印をつける` | **D** | Gambar Soal | 52 kata |
| 44 | `konstruksi01-q044` | Hlm. 36 (131) | `5.2.4 測る・点検する` | **A** | Gambar Soal | 48 kata |
| 45 | `konstruksi01-q045` | Hlm. 37 (132) | `5.2.4 測る・点検する` | **C** | Gambar Soal | 46 kata |
| 46 | `konstruksi01-q046` | Hlm. 40 (135) | `5.2.6 たたく・引き抜く / 5.2.7 削る・みがく` | **A** | Gambar Soal | 43 kata |
| 47 | `konstruksi01-q047` | Hlm. 41 (136) | `5.2.8 締める・固定する` | **D** | Gambar Soal | 36 kata |
| 48 | `konstruksi01-q048` | Hlm. 43 (138) | `5.2.10 養生する / 5.2.11 汚れを落とす` | **C** | Gambar Soal | 49 kata |
| 49 | `konstruksi01-q049` | Hlm. 44 (139) | `5.2.12 物を運ぶ / 5.2.13 吊る・持ち上げる` | **B** | Gambar Soal | 43 kata |
| 50 | `konstruksi01-q050` | Hlm. 46 (141) | `5.2.14 作業台・はしご / 5.2.15 清掃する` | **C** | Gambar Soal | 41 kata |
